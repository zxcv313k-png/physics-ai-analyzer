package com.example.physicsai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhysicsAIApp() }
    }
}

@Composable
fun PhysicsAIApp() {
    var equation by remember { mutableStateOf("dτ = F dT") }
    var result by remember { mutableStateOf("أدخل معادلة ثم اختر نوع الاختبار.") }
    var noPatching by remember { mutableStateOf(true) }

    MaterialTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("المحلل الفيزيائي AI", fontSize = 28.sp)
                    Text("AI Physics Analyzer — الإصدار 0.1")
                    OutlinedTextField(
                        value = equation,
                        onValueChange = { equation = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("المعادلة") },
                        minLines = 3
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Switch(noPatching, { noPatching = it })
                        Text("وضع بدون ترقيع / فرضيات إضافية")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ result = analyzeEquation(equation, noPatching) }, Modifier.weight(1f)) { Text("تحليل") }
                        OutlinedButton({ result = deriveEquation(equation) }, Modifier.weight(1f)) { Text("اشتقاق") }
                    }
                    OutlinedButton({ result = closureTest(equation) }, Modifier.fillMaxWidth()) {
                        Text("اختبار الإغلاق الرياضي")
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("النتيجة", fontSize = 20.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(result, lineHeight = 24.sp)
                        }
                    }
                    HorizontalDivider()
                    Text("مبدأ البرنامج", fontSize = 20.sp)
                    Text("الذكاء الاصطناعي يقترح ويشرح، بينما محرك التحقق الرياضي يفحص النتيجة. هذه نسخة أولية، وسيُضاف الربط الحقيقي بالـAI ومحرك رمزي متقدم لاحقًا.")
                }
            }
        }
    }
}

fun analyzeEquation(eq: String, noPatching: Boolean): String =
    if (eq.isBlank()) "⚠ الرجاء إدخال معادلة."
    else "تحليل أولي\n\nالمعادلة: $eq\n✓ تم استقبال المعادلة.\n" +
         if (noPatching) "✓ وضع بدون ترقيع فعال.\n⚠ التحقق الرمزي الكامل سيضاف لاحقًا."
         else "⚠ وضع بدون ترقيع غير فعال."

fun deriveEquation(eq: String): String =
    if (eq.isBlank()) "⚠ الرجاء إدخال معادلة."
    else "الاشتقاق: $eq\n\n⚠ محرك الاشتقاق الرمزي الكامل قيد البناء."

fun closureTest(eq: String): String =
    if (eq.trim() == "dτ = F dT")
        "اختبار الإغلاق\n\nالبداية:\ndτ = F dT\n\nالصيغة التكاملية:\nτ(T) = ∫ F(T) dT + C\n\nالاشتقاق العكسي:\ndτ/dT = F(T)\n\n✓ الإغلاق البنيوي للخطوة التكاملية ناجح.\n⚠ هذا لا يثبت وحده الصحة الفيزيائية."
    else "⚠ لم تُبرمج بعد قاعدة إغلاق لهذه المعادلة."
